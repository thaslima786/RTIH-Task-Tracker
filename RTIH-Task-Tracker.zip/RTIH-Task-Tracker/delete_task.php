<?php
session_start();
require_once "db.php";

// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Allow deletion only through POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: dashboard.php");
    exit();
}

// Verify CSRF token
if (
    !isset($_POST["csrf_token"]) ||
    !hash_equals($_SESSION["csrf_token"] ?? "", $_POST["csrf_token"])
) {
    die("Invalid request. Please try again.");
}

// Validate task ID
$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    die("Invalid task ID.");
}

// Delete only the logged-in user's task
$stmt = $pdo->prepare(
    "DELETE FROM tasks WHERE id = ? AND user_id = ?"
);

$stmt->execute([$id, $_SESSION["user_id"]]);

header("Location: dashboard.php?deleted=1");
exit();
?>