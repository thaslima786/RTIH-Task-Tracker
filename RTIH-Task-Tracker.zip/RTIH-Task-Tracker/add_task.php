<?php
session_start();
require_once "db.php";

// Only logged-in users can add tasks
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Create CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Verify CSRF token
    if (
        !isset($_POST["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])
    ) {
        $error = "Invalid request. Please try again.";
    } else {

        $title = trim($_POST["title"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $status = $_POST["status"] ?? "Pending";

        $allowedStatuses = ["Pending", "In Progress", "Completed"];

        if ($title === "") {
            $error = "Please enter a task title.";
        } elseif (strlen($title) > 255) {
            $error = "Task title must not exceed 255 characters.";
        } elseif (!in_array($status, $allowedStatuses, true)) {
            $error = "Please select a valid task status.";
        } else {

            $stmt = $pdo->prepare(
                "INSERT INTO tasks (title, description, status, user_id)
                 VALUES (?, ?, ?, ?)"
            );

            $stmt->execute([
                $title,
                $description,
                $status,
                $_SESSION["user_id"]
            ]);

            header("Location: dashboard.php?added=1");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Task | RTIH Task Tracker</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7fb;
            color: #202b40;
        }

        .navbar {
            background: #1e293b;
            color: white;
            padding: 17px 7%;
            font-size: 23px;
            font-weight: bold;
        }

        .container {
            max-width: 650px;
            margin: 45px auto;
            padding: 0 20px;
        }

        .form-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.06);
        }

        h2 {
            margin-bottom: 8px;
        }

        .subtitle {
            color: #718096;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            font-size: 14px;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            font-size: 14px;
            font-family: Arial, sans-serif;
        }

        textarea {
            height: 110px;
            resize: vertical;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #4f46e5;
        }

        .error {
            color: #dc2626;
            background: #fef2f2;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .buttons {
            display: flex;
            gap: 12px;
            margin-top: 25px;
        }

        button,
        .cancel {
            padding: 12px 20px;
            border: none;
            border-radius: 7px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
        }

        button {
            background: #4f46e5;
            color: white;
        }

        button:hover {
            background: #4338ca;
        }

        .cancel {
            background: #e2e8f0;
            color: #334155;
        }

        @media (max-width: 500px) {
            .form-card {
                padding: 20px;
            }

            .buttons {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

    <header class="navbar">
        RTIH Task Tracker
    </header>

    <main class="container">

        <div class="form-card">

            <h2>Add New Task</h2>
            <p class="subtitle">Enter the details of your new task below.</p>

            <?php if ($error !== ""): ?>
                <div class="error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="add_task.php">

                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION["csrf_token"]); ?>">

                <div class="form-group">
                    <label for="title">Task Title *</label>
                    <input type="text" id="title" name="title" maxlength="255"
                        value="<?php echo htmlspecialchars($_POST["title"] ?? ""); ?>"
                    placeholder="Enter task title"
                    required
                    >
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description"
                        placeholder="Enter task description"><?php echo htmlspecialchars($_POST["description"] ?? ""); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="status">Task Status</label>
                    <select id="status" name="status">
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                    </select>
                </div>

                <div class="buttons">
                    <button type="submit">Save Task</button>
                    <a href="dashboard.php" class="cancel">Cancel</a>
                </div>

            </form>

        </div>

    </main>

</body>

</html>