<?php
session_start();
require_once "db.php";

// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Validate task ID
$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    die("Invalid task ID.");
}

// Fetch only the logged-in user's task
$stmt = $pdo->prepare(
    "SELECT * FROM tasks WHERE id = ? AND user_id = ?"
);
$stmt->execute([$id, $_SESSION["user_id"]]);

$task = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$task) {
    http_response_code(404);
    die("Task not found or access denied.");
}

// CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (
        !isset($_POST["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])
    ) {
        $error = "Invalid request. Please try again.";
    } else {

        $title = trim($_POST["title"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $status = $_POST["status"] ?? "";

        $allowedStatuses = ["Pending", "In Progress", "Completed"];

        if ($title === "") {
            $error = "Task title is required.";
        } elseif (strlen($title) > 255) {
            $error = "Task title must not exceed 255 characters.";
        } elseif (!in_array($status, $allowedStatuses, true)) {
            $error = "Please select a valid status.";
        } else {

            $update = $pdo->prepare(
                "UPDATE tasks
                 SET title = ?, description = ?, status = ?
                 WHERE id = ? AND user_id = ?"
            );

            $update->execute([
                $title,
                $description,
                $status,
                $id,
                $_SESSION["user_id"]
            ]);

            header("Location: dashboard.php?updated=1");
            exit();
        }

        // Keep entered values if validation fails
        $task["title"] = $title;
        $task["description"] = $description;
        $task["status"] = $status;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task | RTIH Task Tracker</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7fb;
            color: #202b40;
        }

        .navbar {
            background: #1e293b;
            color: white;
            padding: 17px 7%;
            font-size: 23px;
            font-weight: bold;
        }

        .container {
            max-width: 650px;
            margin: 45px auto;
            padding: 0 20px;
        }

        .form-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.06);
        }

        h2 {
            margin-bottom: 8px;
        }

        .subtitle {
            color: #718096;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            font-size: 14px;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            font-size: 14px;
            font-family: Arial, sans-serif;
        }

        textarea {
            height: 110px;
            resize: vertical;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #4f46e5;
        }

        .error {
            color: #dc2626;
            background: #fef2f2;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .buttons {
            display: flex;
            gap: 12px;
            margin-top: 25px;
        }

        button,
        .cancel {
            padding: 12px 20px;
            border: none;
            border-radius: 7px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
        }

        button {
            background: #4f46e5;
            color: white;
        }

        button:hover {
            background: #4338ca;
        }

        .cancel {
            background: #e2e8f0;
            color: #334155;
        }

        @media (max-width: 500px) {
            .form-card {
                padding: 20px;
            }

            .buttons {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

    <header class="navbar">
        RTIH Task Tracker
    </header>

    <main class="container">

        <div class="form-card">

            <h2>Edit Task</h2>
            <p class="subtitle">Update your task details below.</p>

            <?php if ($error !== ""): ?>
                <div class="error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="edit_task.php?id=<?php echo (int) $id; ?>">

                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION["csrf_token"]); ?>">

                <div class="form-group">
                    <label for="title">Task Title *</label>
                    <input type="text" id="title" name="title" maxlength="255"
                        value="<?php echo htmlspecialchars($task["title"]); ?>" required>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description"
                        name="description"><?php echo htmlspecialchars($task["description"] ?? ""); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="status">Task Status</label>
                    <select id="status" name="status">
                        <?php foreach (["Pending", "In Progress", "Completed"] as $option): ?>
                            <option value="<?php echo $option; ?>" <?php echo ($task["status"] === $option) ? "selected" : ""; ?>>
                                <?php echo $option; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="buttons">
                    <button type="submit">Update Task</button>
                    <a href="dashboard.php" class="cancel">Cancel</a>
                </div>

            </form>

        </div>

    </main>

</body>

</html>