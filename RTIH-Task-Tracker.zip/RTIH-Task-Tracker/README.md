# RTIH Task Tracker

## Project Description

RTIH Task Tracker is a web-based task management application developed using PHP, MySQL (MariaDB), HTML and CSS.

It allows users to register, log in securely, create and manage personal tasks, update task statuses, and search tasks by title.

## Technologies Used

- PHP
- MySQL / MariaDB
- HTML
- CSS
- JavaScript
- XAMPP

## Features

- User registration and login
- Secure password hashing
- Session-based authentication
- Protected user dashboard
- Add, view, edit and delete tasks
- Task status management:
  - Pending
  - In Progress
  - Completed
- Search tasks by title
- Clear search results
- Dashboard task statistics
- Prepared SQL statements and input validation

## Project Setup

1. Install and open XAMPP.
2. Start Apache.
3. Start MariaDB/MySQL.
4. Place the project folder inside `htdocs`.
5. Import `database.sql` into MariaDB using phpMyAdmin or the MySQL command line.
6. Check the database connection settings in `db.php`.
7. Open the application:

   http://localhost/RTIH-Task-Tracker/

8. Register a new account and log in.

## Database

Database name: `rtih_task_tracker`

Tables:

- `users`
- `tasks`

Database backup: `database.sql`

## Testing

The following features were tested:

- User registration and login
- Add, view, edit and delete tasks
- Update task status
- Search existing tasks
- Search with no matching results
- Clear search
- Dashboard statistics

## Backup and Restore

The database can be backed up using `mysqldump`.

To restore:

```bash
mysql -u root -p rtih_task_tracker < database.sql
```

## AI Assistance Disclosure

AI assistance was used for debugging, understanding PHP code, improving the application, and preparing documentation. The code was reviewed and tested during development.

## Project Status

Core task management and search functionality implemented and tested.
