<?php
session_start();
require_once "db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Create a CSRF token if one does not already exist
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Get the search text
$search = trim($_GET["search"] ?? "");

// Search tasks belonging to the logged-in user
$stmt = $pdo->prepare(
    "SELECT * FROM tasks
     WHERE user_id = ? AND title LIKE ?
     ORDER BY created_at DESC"
);

$stmt->execute([
    $_SESSION["user_id"],
    "%" . $search . "%"
]);

$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = count($tasks);
$pending = 0;
$progress = 0;
$completed = 0;

foreach ($tasks as $task) {
    if ($task["status"] === "Pending") {
        $pending++;
    } elseif ($task["status"] === "In Progress") {
        $progress++;
    } elseif ($task["status"] === "Completed") {
        $completed++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RTIH Task Tracker - Dashboard</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7fb;
            color: #202b40;
        }

        /* Navigation */
        .navbar {
            background: #1e293b;
            color: white;
            padding: 17px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 23px;
            font-weight: bold;
        }

        .logout {
            background: #ef4444;
            color: white;
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
        }

        .logout:hover {
            background: #dc2626;
        }

        /* Main layout */
        .container {
            max-width: 1150px;
            margin: 35px auto;
            padding: 0 22px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h1 {
            font-size: 27px;
            margin-bottom: 8px;
        }

        .welcome p {
            color: #718096;
            font-size: 15px;
        }

        /* Statistics */
        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
            border: 1px solid #edf0f5;
        }

        .stat-card p {
            color: #718096;
            font-size: 14px;
            margin-bottom: 12px;
        }

        .stat-card h2 {
            font-size: 27px;
        }

        .stat-card:nth-child(1) h2 {
            color: #4f46e5;
        }

        .stat-card:nth-child(2) h2 {
            color: #e59b25;
        }

        .stat-card:nth-child(3) h2 {
            color: #3182ce;
        }

        .stat-card:nth-child(4) h2 {
            color: #16a36a;
        }

        /* Task section */
        .task-section {
            background: white;
            border-radius: 10px;
            padding: 24px;
            border: 1px solid #edf0f5;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }


        .task-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .add-btn {
            background: #4f46e5;
            color: white;
            padding: 11px 17px;
            border-radius: 7px;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
        }

        .add-btn:hover {
            background: #4338ca;
        }

        .task-heading h2 {
            font-size: 20px;
        }

        /* Empty state */
        .empty-state {
            background: #f8faff;
            border: 1px dashed #cbd5e1;
            border-radius: 9px;
            text-align: center;
            padding: 38px 15px;
        }

        .empty-icon {
            font-size: 35px;
            margin-bottom: 12px;
        }

        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
        }

        .empty-state p {
            font-size: 14px;
            color: #718096;
            line-height: 1.6;
        }

        /* Table */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 14px;
            border-bottom: 1px solid #edf0f5;
            text-align: left;
            font-size: 14px;
        }

        th {
            background: #f8faff;
            color: #64748b;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            background: #eef2ff;
            color: #4338ca;
        }

        footer {
            text-align: center;
            color: #94a3b8;
            font-size: 13px;
            padding: 20px;
        }

        /* Responsive */
        @media (max-width: 750px) {
            .stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .navbar {
                padding: 16px 5%;
            }

            .logo {
                font-size: 19px;
            }

            .container {
                margin-top: 25px;
            }

            .task-section {
                padding: 16px;
                overflow-x: auto;
            }
        }

        @media (max-width: 420px) {
            .stats {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }

            .stat-card {
                padding: 14px;
            }

            .welcome h1 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

    <header class="navbar">
        <div class="logo">RTIH Task Tracker</div>
        <a href="logout.php" class="logout">Logout</a>
    </header>

    <main class="container">

        <section class="welcome">
            <h1>
                Welcome,
                <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!
            </h1>
            <p>Organize your work, track your progress and stay productive.</p>
        </section>

        <section class="stats">

            <div class="stat-card">
                <p>Total Tasks</p>
                <h2>
                    <?php echo $total; ?>
                </h2>
            </div>

            <div class="stat-card">
                <p>Pending</p>
                <h2>
                    <?php echo $pending; ?>
                </h2>
            </div>

            <div class="stat-card">
                <p>In Progress</p>
                <h2>
                    <?php echo $progress; ?>
                </h2>
            </div>

            <div class="stat-card">
                <p>Completed</p>
                <h2>
                    <?php echo $completed; ?>
                </h2>
            </div>

        </section>

        <section class="task-section">


            <div class="task-heading">
                <h2>My Tasks</h2>

                <a href="add_task.php" class="add-btn">+ Add New Task</a>
            </div>
            <form method="GET" action="dashboard.php" style="display:flex; gap:10px; margin-bottom:20px;">

                <input type="text" name="search" placeholder="Search task by title..."
                    value="<?php echo htmlspecialchars($search); ?>" style="flex:1; padding:11px; border:1px solid #cbd5e1;
        border-radius:6px; font-size:14px;">

                <button type="submit" style="background:#4f46e5; color:white; border:none;
        padding:10px 18px; border-radius:6px; cursor:pointer;">
                    Search
                </button>

                <a href="dashboard.php" style="background:#64748b; color:white; padding:10px 18px;
       border-radius:6px; text-decoration:none;">
                    Clear
                </a>

            </form>

            <?php if ($total > 0): ?>

                <table>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>

                    <?php foreach ($tasks as $task): ?>
                        <tr>
                            <td>
                                <?php echo (int) $task["id"]; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($task["title"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($task["description"] ?? ""); ?>
                            </td>

                            <td>
                                <span class="status">
                                    <?php echo htmlspecialchars($task["status"]); ?>
                                </span>
                            </td>

                            <td>
                                <a href="edit_task.php?id=<?php echo (int) $task['id']; ?>"
                                    style="color:#4f46e5; text-decoration:none; font-weight:bold;">
                                    Edit
                                </a>

                                <form method="POST" action="delete_task.php" style="display:inline;"
                                    onsubmit="return confirm('Are you sure you want to delete this task?');">

                                    <input type="hidden" name="id" value="<?php echo (int) $task['id']; ?>">

                                    <input type="hidden" name="csrf_token"
                                        value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

                                    <button type="submit" style="background:#ef4444;color:white;border:none;
                padding:7px 10px;border-radius:5px;cursor:pointer;
                margin-left:8px;">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                </table>

            <?php else: ?>

                <div class="empty-state">
                    <div class="empty-icon">📋</div>
                    <h3>No tasks found!</h3>
                    <p>Try searching with a different task title.</p>
                </div>

            <?php endif; ?>



        </section>

    </main>

    <footer>
        © 2026 RTIH Task Tracker. All rights reserved.
    </footer>

</body>

</html>